
import streamlit as st
import requests

st.set_page_config(page_title="Natural Language to Elasticsearch DSL", layout="wide")

st.title("🔍 Natural Language → Elasticsearch Query DSL")
st.markdown("Enter a request in plain English and get a valid Elasticsearch JSON DSL query.")

query = st.text_input("Enter your natural language query:", placeholder="e.g., Show failed logins in the last 24 hours")

if st.button("Translate"):
    if not query:
        st.warning("Please enter a query first.")
    else:
        with st.spinner("Translating with LLM..."):
            try:
                response = requests.post("http://localhost:8001/translate", json={"query": query})
                data = response.json()
                st.code(data["dsl"], language="json")
            except Exception as e:
                st.error(f"Error: {e}")
