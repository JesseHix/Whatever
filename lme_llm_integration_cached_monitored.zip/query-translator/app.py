
from fastapi import FastAPI, Request
from pydantic import BaseModel
import requests
import os
from datetime import datetime
import logging

app = FastAPI()

MODEL = os.getenv("MODEL", "gemma:2b")

# Set up basic logging
logging.basicConfig(filename="/app/query_logs.log", level=logging.INFO, format="%(asctime)s - %(message)s")

# Precomputed cache of common queries
CACHE = {
    "show failed logins in the last 24 hours": {
        "query": {
            "bool": {
                "must": [
                    {"match": {"event.outcome": "failure"}},
                    {"range": {"timestamp": {"gte": "now-24h", "lte": "now"}}}
                ]
            }
        }
    },
    "show logins by user alice in the last 7 days": {
        "query": {
            "bool": {
                "must": [
                    {"match": {"user.name": "alice"}},
                    {"range": {"timestamp": {"gte": "now-7d", "lte": "now"}}}
                ]
            }
        }
    },
    "list successful logins from the past week": {
        "query": {
            "bool": {
                "must": [
                    {"match": {"event.outcome": "success"}},
                    {"range": {"timestamp": {"gte": "now-7d", "lte": "now"}}}
                ]
            }
        }
    },
    "get login attempts from ip 192.168.1.100": {
        "query": {
            "match": {"source.ip": "192.168.1.100"}
        }
    },
    "fetch all logins for user bob today": {
        "query": {
            "bool": {
                "must": [
                    {"match": {"user.name": "bob"}},
                    {"range": {"timestamp": {"gte": "now/d", "lte": "now"}}}
                ]
            }
        }
    }
}

class QueryInput(BaseModel):
    query: str

@app.post("/translate")
def translate_query(input: QueryInput, request: Request):
    user_ip = request.client.host
    user_query = input.query.strip().lower()
    log_entry = f"IP: {user_ip}, Query: {user_query}"
    logging.info(log_entry)

    if user_query in CACHE:
        return {"dsl": CACHE[user_query]}

    # LLM fallback
    prompt = f"""
Translate this natural language request into Elasticsearch JSON DSL.
Only return valid Elasticsearch JSON. Do not include any explanation.

Example input: Show failed login attempts in the past 24 hours
Example output:
{{
  "query": {{
    "bool": {{
      "must": [
        {{ "match": {{ "event.outcome": "failure" }} }},
        {{ "range": {{ "timestamp": {{ "gte": "now-24h", "lte": "now" }} }} }}
      ]
    }}
  }}
}}

Now translate this:
"{input.query}"
"""

    response = requests.post("http://ollama:11434/api/generate", json={
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "temperature": 0.2
    })

    return {"dsl": response.json()["response"].strip()}
