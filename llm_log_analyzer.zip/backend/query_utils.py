from elasticsearch8 import Elasticsearch

es = Elasticsearch(
    hosts=["https://20.168.25.73:9200"],
    basic_auth=("elastic", "qDkHWMelXBq7z!0v6WibSRmNIo5spl"),
    verify_certs=False
)

def run_query(query_body):
    try:
        response = es.search(index="*", body=eval(query_body))
        return response['hits']['hits']
    except Exception as e:
        return [{"error": str(e)}]