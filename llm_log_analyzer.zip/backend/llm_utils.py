import requests

def translate_nl_to_dsl(nl_query):
    prompt = f"Convert this to Elasticsearch DSL JSON format only: {nl_query}"
    response = requests.post(
        "http://ollama:11434/api/generate",
        json={"model": "llama2", "prompt": prompt, "stream": False}
    )
    return response.json().get("response", "{}")

def summarize_results(results):
    if not results:
        return "No results found."
    if "error" in results[0]:
        return f"Error: {results[0]['error']}"
    summary = f"Returned {len(results)} entries. Top fields:
"
    for item in results[:3]:  # show top 3 entries
        summary += f"{item['_source']}

"
    return summary