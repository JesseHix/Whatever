from flask import Flask, render_template, request, send_file
import json
from io import BytesIO
from query_utils import run_query
from llm_utils import translate_nl_to_dsl, summarize_results

app = Flask(__name__)

predefined_queries = [
    "Show all failed login attempts from the last 24 hours",
    "List PowerShell executions in the last 7 days",
    "Display firewall disable events this week",
    "Find clipboard access logs",
    "Show malware detections (Trojans)",
    "List Kubernetes container start events"
]

@app.route("/", methods=["GET", "POST"])
raw_results = []

def index():
    result = ""
    user_query = ""
    if request.method == "POST":
        user_query = request.form["query"]
        dsl = translate_nl_to_dsl(user_query)
        results = run_query(dsl)
        global raw_results
        raw_results = results
        result = summarize_results(results)
    return render_template("index.html", result=result, user_query=user_query, predefined_queries=predefined_queries, raw_data=raw_results)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

@app.route("/download")
def download():
    global raw_results
    data = json.dumps(raw_results, indent=2)
    buffer = BytesIO(data.encode("utf-8"))
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name="query_results.json", mimetype="application/json")
