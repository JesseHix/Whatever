def test_translation_format():
    from backend.llm_utils import translate_nl_to_dsl
    query = "Show failed logins in the last 24 hours"
    dsl = translate_nl_to_dsl(query)
    assert "query" in dsl or "match" in dsl or "range" in dsl
def test_summarization_format():
    from backend.llm_utils import summarize_results
    mock_data = [
        {"_source": {"event": "login failure", "user": "admin"}},
        {"_source": {"event": "login failure", "user": "guest"}}
    ]
    summary = summarize_results(mock_data)
    assert "Returned" in summary and "admin" in summary
