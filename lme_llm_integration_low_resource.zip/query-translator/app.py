
from fastapi import FastAPI
from pydantic import BaseModel
import requests
import os

app = FastAPI()

MODEL = os.getenv("MODEL", "codellama:instruct")

class QueryInput(BaseModel):
    query: str

@app.post("/translate")
def translate_query(input: QueryInput):
    prompt = f"""
Translate this natural language request into Elasticsearch JSON DSL.
Only return valid Elasticsearch JSON. Do not include any explanation.

Example input: Show failed login attempts in the past 24 hours
Example output:
{{
  "query": {{
    "bool": {{
      "must": [
        {{ "match": {{ "event.outcome": "failure" }} }},
        {{ "range": {{ "timestamp": {{ "gte": "now-24h", "lte": "now" }} }} }}
      ]
    }}
  }}
}}

Now translate this:
"{input.query}"
"""

    response = requests.post("http://ollama:11434/api/generate", json={
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "temperature": 0.2
    })

    return {"dsl": response.json()["response"].strip()}
