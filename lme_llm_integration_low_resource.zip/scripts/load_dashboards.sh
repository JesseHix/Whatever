#!/bin/bash
echo "Waiting for Kibana..."
sleep 30
echo "Importing dashboards..."
curl -X POST "http://kibana:5601/api/saved_objects/_import?overwrite=true" \
  -H "kbn-xsrf: true" \
  --form file=@/dashboards/failed_logins.json