#!/bin/bash
echo "Waiting for Elasticsearch..."
sleep 20
echo "Loading sample data into Elasticsearch..."
curl -H "Content-Type: application/x-ndjson" -XPOST "http://elasticsearch:9200/logs/_bulk?pretty" --data-binary @/data/sample_login_events.jsonl